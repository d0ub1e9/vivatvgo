﻿# -*- coding: utf-8 -*-
import os
import sys
import json
import time
import xbmc
import base64
import urllib
import xbmcgui
import pickle
import requests
import xbmcaddon
import xbmcplugin
from datetime import datetime, timedelta
from resources.lib.settings import *

reload(sys)  
sys.setdefaultencoding('utf8')

def save_cookies(s):
  with open(cookie_file, 'w') as f:
    f.truncate()
    pickle.dump(s.cookies._cookies, f)
  return True

def load_cookies():
  jar = requests.cookies.RequestsCookieJar()
  if os.path.isfile(cookie_file):
    with open(cookie_file) as f:
      cookies = pickle.load(f)
      if cookies:
        jar._cookies = cookies
        return jar
  return jar
  
def __request(url, payload=None):
  headers = {'User-Agent': 'okhttp/2.5.0', 'USER_AGENT': 'android'}
  method = "POST" if payload else "GET"
  log("**************************************************")
  log("%s %s" % (method, url))
  for key,val in headers.items():
    log("%s: %s" % (key, val))
  if payload:
    res = session.post(url, json=payload, headers=headers)
    ## Obfuscate password in logs
    if settings.obfuscate:
      _pass = payload.get("password")
      if _pass:
        payload["password"] = "********"
    log("%s" % json.dumps(payload))
  else:
    res = session.get(url, headers=headers)
  if settings.debug:
    with open(response_file, "w") as w:
      w.write(res.text)
  return res
  
def login():
  url =  base64.b64decode("aHR0cDovL3R2Z28udml2YWNvbS5iZzo4MDgyL0VEUy9KU09OL0xvZ2luP1VzZXJJRD0lcw==") % settings.username
  res = __request(url)
  settings.url = res.json()["epgurl"]
  
  url = get_url(base64.b64decode("Vml2YWNvbVNTT0F1dGg="))
  post_data = {"password": settings.password, "userName": settings.username}
  res = __request(url, post_data)
  msg = "Неочаквана грешка. Моля проверете лога"
  if res.json().get("retcode") and res.json()["retcode"] != "0":
    if res.json().get("retmsgBG"):
      msg = res.json()["retmsgBG"]
    elif res.json().get("retmsg"):
      msg = res.json()["retmsg"]
    elif res.json().get("desc"):
      msg = res.json()["desc"]
    
    log(res.text)
    
    command = "Notification(%s,%s,%s)" % ("Грешка", msg.encode('utf-8'), 5000)
    xbmc.executebuiltin(command)
    return False

  settings.checksum = res.json()[base64.b64decode("dml2YWNvbVN1YnNjcmliZXJz")][0]["checksum"]
  settings.subscriberId = res.json()[base64.b64decode("dml2YWNvbVN1YnNjcmliZXJz")][0]["subscriberId"]

  post_data = {"checksum":settings.checksum,"mac":settings.guid,"subscriberId":settings.subscriberId,"terminaltype":"NoCAAndroidPhone","userName":settings.username}
  res = __request(url, post_data)
  settings.subscriberPassword = res.json()["users"][0]["password"]
  
  save_cookies(session)
  
  return True

def get_channels():
  if login():
    post_data = {"id": settings.subscriberId, "password": settings.subscriberPassword}
    res = __request(get_url(base64.b64decode("U3dpdGNoUHJvZmlsZQ==")), post_data)
    if settings.debug:
      with open(response_file, "w") as w:
        w.write(res.text)     
        
    post_data = {"checksum":settings.checksum,"mac":settings.guid,"subscriberId":settings.subscriberId,"terminaltype":"NoCAAndroidPhone","userName":settings.username}
    res = __request(get_url(base64.b64decode("QWxsQ2hhbm5lbA==")), post_data)
    channels = []
    if not res.json().get("channellist"):
      return None
      
    for item in res.json()["channellist"]:
      channel = {}
      channel["name"] = item["name"]
      channel["id"] = item["id"]
      
      playpaths = []
      try: playpaths = item["playurl"].split("|")
      except:
        try: playpaths[0] = item["playurl"]
        except: log("No playpath found for channel %s" % item["name"], 4)
      
      channel["playpaths"] = playpaths
      channel["logo"] = item.get("logo").get("url")
      channels.append(channel)
      
    with open(channels_file, "w") as w:
      w.write(json.dumps(channels, ensure_ascii=False))
    
    log("%s channels found" % len(channels_file))
    return channels
  else:
    return None

def get_channel(id):
  try:
    with open(channels_file) as f:
      channels = json.load(f)
      for channel in channels:
        if channel["id"] == id:
          return channel
    log("Channel with id %s not found" % id, 4)
  except Exception as er:
    log(er, 4)
  return None
    
def get_dates():
  now = datetime.now()
  dates = []
  for i in range (0, 7):
    then = now - timedelta(days=i)
    date = then.strftime("%d-%m-%Y")
    dates.append(date)
  return dates
  
def get_recorded_programs(id, date):
  log("Getting EPG")
  try: # second use bug https://forum.kodi.tv/showthread.php?tid=112916
    dt = datetime.strptime(date, "%d-%m-%Y")
  except TypeError:
    dt = datetime.fromtimestamp(time.mktime(time.strptime(date, "%d-%m-%Y")))
  begintime = dt.strftime("%Y%m%d000000")
  endtime = dt.strftime("%Y%m%d240000")
  
  post_data = {"begintime":begintime,"channelid":id,"count":"1000","endtime":endtime,"offset":0,"type":2}
  res = __request(get_url("PlayBillList"), post_data)
  if settings.debug:
    with open(programs_file, "w") as w:
      w.write(res.text)
  
  if res.json().get("retcode") and res.json()["retcode"] != "0":
    if res.json().get("desc"):
      command = "Notification(%s,%s,%s)" % ("Error", res.json()["desc"].encode('utf-8'), 5000)
      xbmc.executebuiltin(command) 
    return []
  else:
    log("%s programs found for channel id %s" % (res.json()["counttotal"], id))
    return res.json()["playbilllist"]
  
def get_stream(id, mediaId):
  playurl = None
  try:
    post_data = {"businessType":"5","contentId":id,"contentType":"PROGRAM","mediaId":mediaId,"priceType":"-1","pvrId":0}
    res = __request(get_url(base64.b64decode("QXV0aG9yaXplQW5kUGxheQ==")), post_data)
    playurl = res.json()["playUrl"]
    log("Found playurl: %s" % playurl)
  except Exception as er:
    log(er, 4)
    log(res.txt)
  return playurl

def get_url(name):  
  return settings.url + base64.b64decode("L0VQRy9KU09OLw==") + name
  
session = requests.session()
session.cookies = load_cookies()